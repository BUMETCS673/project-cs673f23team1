<template>
  <div id="goods-content" :style="$store.state.collapsed ? 'margin: 0 10px;' : ''">
    <div class="tag">
      <a-badge class="info-box"
               :style="$store.state.collapsed ? 'width:100%;' : 'width:50%;border-right: 20px solid #f0f2f5;'"
               v-for="item of data" :key="item.id">
        <div class="goods_goods" @click="routerUrl(item.url)">
          <img :src="item.image" style="width: 200px" alt=""/>
          <div style="color: red; font-weight: 700;font-size: 30px">{{ item.price }}</div>
          <div class="title">{{ item.title }}</div>
          <div class="meta-post">{{ item.desc }}</div>
        </div>
      </a-badge>
    </div>
  </div>
</template>

<script>
import postService from "@/service/postService";

export default {
  data() {
    return {
      data: [],
    }
  },

  methods: {
    getGoods() {
      postService.getGoods()
          .then(res => {
            this.data = res.data;
          })
          .catch(err => {
            this.$message.error(err.desc);
          });
    },

    routerUrl(url) {
      window.open(url);
    },

  },

  mounted() {
    this.getGoods();
  },
}
</script>

<style lang="less" scoped>
#goods-content {
  .tag {
    display: flex;
    flex-wrap: wrap;
  }

  .info-box {
    background: #fff;
    border-bottom: 20px solid #f0f2f5;

    .goods_goods {
      padding: 20px;
      display: flex;
      flex-direction: column;
      align-items: center;
      cursor: pointer;
    }

    .title, .avatar {
      border-radius: 0;
    }

    .title {
      padding-top: 5px;
      font-size: 20px;
      line-height: 40px;
      color: #333;
    }

    .meta-post {
      font-size: 14px;
      color: #b0b0b0;
    }
  }
}

</style>
