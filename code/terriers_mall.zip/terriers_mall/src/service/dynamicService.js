import axios from "axios";

export default {
  
  getDynamicList(params) {
    return new Promise((resolve, reject) => {
      axios.get("/api/bbs/dynamic/getList", {params})
          .then((res) => resolve(res))
          .catch((err) => reject(err));
    });
  },

};
