<template>
  <div id="post-detail" ref="scrollDiv"
       :style="$store.state.collapsed ? 'padding: 10px' : 'padding: 20px;'">
    <div v-if="finish">
      <div class="post-title">
        <h1>{{ data.title }}</h1>
        <!-- waiting for review -->
        <span class="iconfont icon-pendingReview" v-if="data.state === -1"
              style="color: #faad14; font-size: 38px;"></span>
        <!-- Review rejected -->
        <span class="iconfont icon-reviewRejected" v-if="data.state === 0" style="color: red; font-size: 38px;"></span>
      </div>
      <div class="post-user">
        <div class="author-info-box">
          <a-avatar class="avatar" :src="data.picture ? data.picture : require('@/assets/img/default_avatar.png')"
                    :size="46" @click="routerUserCenter(data.createUser)"/>
          <div class="author-name-meta" style="padding-left: 10px;">
            <div class="author-name">
              <a target="_blank" class="username" @click="routerUserCenter(data.createUser)">
                <span class="name" style="font-size: 17px;">{{ data.createUserName }} </span>
                <img :src="require('@/assets/img/level/' + data.postCountDTO.level + '.svg')" alt=""
                     @click.stop="routerBook"/>
              </a>
            </div>
            <div class="meta-box" style="color: #8a919f">
            <span class="time">
              {{ data.createTime }}
            </span>
              <span class="views-count">
               {{ $t("common.read") + ' ' + data.pv }}
            </span>
            </div>
          </div>
        </div>
        <div class="follow-box">
          <div class="edit" v-if="$store.state.userId === data.createUser">
            <a-button class="follow-btn" v-if="!data.postCountDTO.isFollow" @click="routerPostEdit(data.id)"
                      :style="{color: $store.state.themeColor, border: '1px solid' + $store.state.themeColor}">
              {{ $t("common.edit") }}
            </a-button>
          </div>
          <div class="follow" v-else>
            <a-button class="follow-btn" v-if="!data.postCountDTO.isFollow"
                      @click="updateFollowState(data.createUser)"
                      :style="{color: $store.state.themeColor, border: '1px solid' + $store.state.themeColor}">
              {{ $t("common.follow") }}
            </a-button>
            <a-button class="follow-btn-close" v-if="data.postCountDTO.isFollow"
                      @click="updateFollowState(data.createUser)">
              {{ $t("common.haveFollowed") }}
            </a-button>
          </div>
        </div>
      </div>
      <div class="post-titleMap" v-if="data.titleMap">
        <img :src="data.titleMap" style="width: 100%;"/>
      </div>
      <div class="post-content" style="width: 100%" v-if="data.markdown">
        <mavon-editor
            :value="data.markdown"
            :subfield="false"
            defaultOpen="preview"
            :toolbarsFlag="false"
            boxShadowStyle="0"
            previewBackground="#fff"
            codeStyle="obsidian"
            :xssOptions=false></mavon-editor>
      </div>
    </div>
    <CustomEmpty v-else/>
  </div>
</template>

<script>
  import postService from "@/service/postService";
  import userService from "@/service/userService";
  import CustomEmpty from "@/components/utils/CustomEmpty";

  export default {
    components: {CustomEmpty},

    data() {
      return {
        finish: false,
        data: {},
      };
    },

    methods: {
      // get detailed information of post
      getPostById() {
        this.finish = false;
        postService.getPostById({id: this.$route.params.id, isPv: true})
            .then(res => {
              this.data = res.data;
              this.finish = true;
              // get label id
              let labelIds = [];
              res.data.labelDTOS.forEach(label => {
                labelIds.push(label.id);
              });
              this.$emit("initLabelIds", labelIds, this.finish, res.data.createUser, this.$utils.toToc(res.data.html));

              if (res.data.html) {
                setTimeout(() => {

                  this.monitorScrollForTopicHighlight();
                  // copy of code block
                  this.$nextTick(() => {
                    clearInterval(this.timer);
                    this.getCodes();
                  });
                }, 800);
              }

            })
            .catch(err => {
              this.finish = true;
              // error: post not exist
              if (err.code === 4) {
                this.$router.push({
                  name: '404',
                  // kept current path and delete first character, to avoid object URL start with `//` 
                  params: {pathMatch: this.$route.path.substring(1).split('/')},
                })
              } else {
                this.$message.error(err.desc);
              }
            });
      },


      monitorScrollForTopicHighlight() {
        const toc = document.querySelector('#markdown-toc');
        if (!toc) return;
        const postContent = document.querySelector('.post-content');
        const topics = postContent.querySelectorAll('h1,h2,h3,h4,h5,h6'); // title
        const lis = toc.querySelectorAll('li'); // list of titles
        const removeActive = () => {
          for (let i = 0; i < lis.length; i++) {
            lis[i].classList.remove('active');
          }
        };

        const tocClickEventCB = ev => {
          if (ev.target.nodeName === 'A') {
            const parentNode = ev.target.parentNode;
            if (parentNode && parentNode.nodeName === 'LI') {
              removeActive();
              parentNode.classList.add('active');
            }
          }
        };
        toc.addEventListener('click', tocClickEventCB);

        const hash = location.hash;
        if (hash) {
          const activeAnchor = toc.querySelector(`a[href="${hash}"]`);
          if (!activeAnchor) {
            lis[0].classList.add('active');
          } else {
            const activeAnchorParent = activeAnchor.parentNode;
            if (activeAnchor) {
              removeActive();
              activeAnchorParent.classList.add('active');
            }
          }
        } else {        
          lis[0].classList.add('active');
        }
        
        const observer = new IntersectionObserver(
            entries => {
              for (const entry of entries) {
                if (entry.intersectionRatio > 0) {
                  const anchor = entry.target.firstElementChild;
                  if (!anchor) return;
                  const id = anchor.getAttribute('id');
                  const activeAnchor = toc.querySelector(`a[href="#${id}"]`);
                  const activeAnchorParent = activeAnchor.parentNode;
                  if (activeAnchor) {
                    removeActive();
                    if (!entry.isIntersecting && entry.intersectionRect.top > 0) {
                      const preTopic = activeAnchorParent.previousSibling;
                      if (preTopic) {
                        preTopic.classList.add('active');
                        break;
                      }
                    }
                    activeAnchorParent.classList.add('active');
                  }
                  break;
                }
              }
            },
            {
              rootMargin: '0% 0% -90% 0%', 
              threshold: 0.6,
            },
        );
        Array.prototype.forEach.call(topics, target => {
          observer.observe(target);
        });
        this.$once('hook:beforeDestroy', () => {
          observer.disconnect();
          toc.removeEventListener('click', tocClickEventCB);
        });
      },

      // update follow state
      updateFollowState(toUser) {
        userService.updateFollowState({toUser: toUser})
            .then(() => {
              this.getPostById();
            })
            .catch(err => {
              this.$message.error(err.desc);
            });
      },

      // route to post edit page
      routerPostEdit(postId) {
        this.$router.push("/edit/" + postId);
      },

      // route to user center
      routerUserCenter(userId) {
        let routeData = this.$router.resolve("/user/" + userId);
        window.open(routeData.href, '_blank');
      },

      // route to book page(introduction page)
      routerBook() {
        let routeData = this.$router.resolve("/book");
        window.open(routeData.href, '_blank');
      },


      // This part of code is aim to use setInterval to wait for katex.min.js completed loading
      // Thus, offsetHeight can successfully gained, else it will kept 0
      // Since dom will be loaded first, and after that will be js/css and others
      getCodes() {
        this.codes = document.querySelectorAll("pre code");
        if (this.codes.length > 0) {
          for (let i = 0; i < this.codes.length; i++) {
            if (this.codes[i].offsetHeight !== 0) {
              return this.init();
            } else {
              this.timer = setInterval(() => {
                for (let j = 0; j < this.codes.length; j++) {
                  if (this.codes[j].offsetHeight !== 0) {
                    clearInterval(this.timer);
                    return this.init();
                  }
                }
              }, 500);
              return;
            }
          }
        }
      },

      init() {
        let thisTemp = this;
        this.$nextTick(() => {
          clearInterval(this.timer);
          this.codes.forEach((item) => {
            let pre = item.parentElement;
            let icon =
                `<div class="code-icon">` +
                `<i class="iconfont icon-copy copy-button"></i>` +
                `</div>`;

            pre.insertAdjacentHTML("afterbegin", icon);
            // get element that will be copied
            let copyButton = pre.firstElementChild.getElementsByClassName("copy-button")[0];
            copyButton.onclick = function () {
              thisTemp.$copyText(pre.lastElementChild.innerText).then(() => {
                thisTemp.$message.success(
                    'copy successful',
                    1,
                );
              }).catch(() => {
                thisTemp.$message.error(
                    'copy failed',
                    1,
                );
              });
            };
          });
        });
      },
    },

    mounted() {
      this.getPostById();
    },

    watch: {
      data: function () {
        this.$nextTick(() => {
          let hash = location.hash;
          if (hash) {
            this.$nextTick(() => {
              setTimeout(() => {
                hash = "[id='" + hash.substring(1, hash.length) + "']"
                if (!hash.includes('reply-')) {
                  document.querySelector(hash).scrollIntoView({behavior: "smooth"});
                } else {
                  document.querySelector(hash).scrollIntoView({behavior: "smooth", block: "center"});
                  document.querySelector(hash).setAttribute('class', 'selectedComment');
                }
              }, 400);
            });
          }
        });
      }
    },
  }
</script>

<style lang="less">
  #post-detail .post-title {
    display: flex;
    //align-items: center;
    justify-content: space-between;

    h1 {
      font-size: 32px;
      font-weight: 700;
      line-height: 1.31;
      color: #252933;
    }

    h2 {
      font-weight: 700;
    }
  }

  #post-detail .post-user {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  #post-detail .author-info-box {
    display: flex;
  }

  #post-detail .avatar {
    cursor: pointer;
  }

  #post-detail .post-titleMap {
    padding-top: 20px;
  }

  #post-detail .post-content {
    padding-top: 20px;

    h1 > a,
    h2 > a,
    h3 > a,
    h4 > a,
    h5 > a,
    h6 > a {
      margin-top: -60px;
      padding-top: 60px;
    }
  }

  /* Follow button */
  #post-detail .follow-btn {
    width: 77px;
    height: 27px;
    border-radius: 2px;
  }

  #post-detail .follow-btn:hover {
    background: #37c701;
    border: 1px solid rgba(55, 199, 1, .6) !important;
    color: #fff !important;
  }

  #post-detail .follow-btn-close {
    background: #37c701;
    border: 1px solid rgba(55, 199, 1, .6) !important;
    color: #fff !important;
    /*width: 77px;*/
    height: 27px;
    border-radius: 2px;
  }

  #post-detail .follow-btn-close:hover {
    background: #3ee002;
    border: 1px solid rgba(55, 199, 1, 0.7) !important;
  }


  #post-detail .markdown-body .highlight pre, .markdown-body pre {
    padding: 0 !important;
  }

  #post-detail .hljs {
    padding: 10px;
  }


  /* style of mavon-editor */
  #post-detail .v-note-wrapper .v-note-panel .v-note-show .v-show-content, .v-note-wrapper .v-note-panel .v-note-show .v-show-content-html {
    padding: 0;
  }

  #post-detail .v-note-wrapper {
    z-index: 900;
  }

  /* set minimum height of mavon-editor */
  #post-detail .v-note-wrapper.markdown-body.shadow {
    min-height: 0;
  }

  /* copy button */
  .code-icon {
    .copy-button {
      padding: 2px 8px;
      color: #ffffff;
      border-radius: 5px;
      float: right;
    }

    .copy-button:hover {
      cursor: pointer;
      background-color: black;
    }
  }

</style>