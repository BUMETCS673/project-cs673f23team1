<template>
  <div id="terriers-value" :style="$store.state.collapsed ? 'padding: 10px 10px 0 10px;' : 'padding: 50px 50px 20px 50px;'">
    <div class="markdown-body">
      <h1>Introduction and explain of Terriers Value</h1>
      <br/>
      <h2>Terriers Value</h2>
      <p>We will use <strong>Terriers Value</strong> in our Terriers Mall to calculate how active the user is in our Mall. You can find your Terriers Value in your user center.</p>
      <h3>Significance of Terriers Value</h3>
      <ol>
        <li>Terriers Value will affect the rank of your post, higher your Value is, higher rank your post will receive, and more users will receive your post, that will make it easier for you to sell your product.</li>
        <li>The higher your Terriers Value is, more function and right you will gain.</li>
        <li>Also Terriers Value will partly help other users know how reliable you are and everyone will be more willing to deal with people who have higher reputation.</li>
      </ol>
      <h3>How Terriers Value calculated</h3>
      <p>Purpose of Terriers Value is to calculate how active user are, but not meaning user must buy or sell a lot(else some user can do fake buy to gain lots of Value), thus we decided:</p>
      <p style="color: red;">Terriers Value = Post user read / 10 + Like user received</p>
      <code class="hljs language-!" lang="!">
        1、Terriers Value will only count post user interact in Terriers Mall.
        <br/>
        2、Terriers Mall will be refreshed <span style="color: red;">1:00AM</span> everyday.
        <br/>
        3、If user delete own post, related Terriers Value will be deleted. If user lose level of Value due to this, correspond right and fuction will also be disabled.
      </code>
      <br/>
      <h2>Terriers level and Rights</h2>
      <table>
        <thead>
        <tr>
          <th>Terriers Level</th>
          <th>Lower bound of Terriers Value</th>
          <th>Higher bound of Terriers Value</th>
          <th>Identity</th>
          <th>Right enjoyed</th>
        </tr>
        </thead>
        <tbody>
        <tr>
          <td>
            <img style="width: 30px;" src="@/assets/img/level/Lv1.svg" alt=""/>
          </td>
          <td>0</td>
          <td>99</td>
          <td>
            <img src="@/assets/img/level/badge-Lv1.svg" alt="" /> Fresh man
          </td>
          <td>Basic functions</td>
        </tr>
        <tr>
          <td>
            <img style="width: 30px;" src="@/assets/img/level/Lv2.svg" alt=""/>
          </td>
          <td>100</td>
          <td>299</td>
          <td>
            <img src="@/assets/img/level/badge-Lv2.svg" alt="" /> User
          </td>
          <td>We are sure you will definately <span style="color: red;">find your life-long love this year</span>!</td>
        </tr>
        <tr>
          <td>
            <img style="width: 30px;" src="@/assets/img/level/Lv3.svg" alt=""/>
          </td>
          <td>300</td>
          <td>599</td>
          <td>
            <img src="@/assets/img/level/badge-Lv3.svg" alt="" /> Active person
          </td>
          <td>You will earn <span style="color: red;">Millions of dollars each year</span>!</td>
        </tr>
        <tr>
          <td>
            <img style="width: 30px;" src="@/assets/img/level/Lv4.svg" alt=""/>
          </td>
          <td>600</td>
          <td>999</td>
          <td>
            <img src="@/assets/img/level/badge-Lv4.svg" alt="" /> My buddy
          </td>
          <td>You can<span style="color: red;">Top your post on home page</span></td>
        </tr>
        <tr>
          <td>
            <img style="width: 30px;" src="@/assets/img/level/Lv5.svg" alt=""/>
          </td>
          <td>1000</td>
          <td>1499</td>
          <td>
            <img src="@/assets/img/level/badge-Lv5.svg" alt="" /> You are my hero!
          </td>
          <td>Own some manage rights, be able to <span style="color: red;">Maintain labels and resourse navigation</span>.</td>
        </tr>
        <tr>
          <td>
            <img style="width: 30px;" src="@/assets/img/level/Lv6.svg" alt=""/>
          </td>
          <td>1500</td>
          <td>2099</td>
          <td>
            <img src="@/assets/img/level/badge-Lv6.svg" alt="" /> I'm yours!
          </td>
          <td>You can do <span style="color: red;">anything you want </span>to Terriers Mall!</td>
        </tr>
        </tbody>
      </table>
      <h3>PENALTY of gain Terriers Value illegal</h3>
      <p>If we find any user who try to gain Terriers Value illegally (for example, use robot for more like, more post read, etc), we will<span style="color: red;">CLEAR ALL TERRIERS VALUE this user own, and REVOCATE ALL FUNCTIONS AND RIGHTS HE UNLOCKED.</span></p>
    </div>
  </div>
</template>

<script>
  export default {
    name: ""
  }
</script>

<style scoped>
  #terriers-value {
    background: #fff;
  }

  h1, h2, h3, h4, h5, h6 {
    font-weight: 700;
  }

  .markdown-body {
    word-break: break-word;
    line-height: 1.75;
    font-weight: 400;
    font-size: 16px;
    overflow-x: hidden;
    color: #333
  }

  .markdown-body h1, .markdown-body h2, .markdown-body h3, .markdown-body h4, .markdown-body h5, .markdown-body h6 {
    line-height: 1.5;
    margin-bottom: 10px;
    padding-bottom: 5px
  }

  .markdown-body h1 {
    font-size: 24px;
    margin-bottom: 5px
  }

  .markdown-body h2, .markdown-body h3, .markdown-body h4, .markdown-body h5, .markdown-body h6 {
    font-size: 20px
  }

  .markdown-body h2 {
    padding-bottom: 12px;
    border-bottom: 1px solid #ececec
  }

  .markdown-body h3 {
    font-size: 18px;
    padding-bottom: 0
  }

  .markdown-body h6 {
    margin-top: 5px
  }

  .markdown-body p {
    line-height: inherit;
    margin-top: 22px;
    margin-bottom: 22px
  }

  .markdown-body img {
    max-width: 100%
  }

  .markdown-body hr {
    border: none;
    border-top: 1px solid #ddd;
    margin-top: 32px;
    margin-bottom: 32px
  }

  .markdown-body code {
    font-size: 14px;
    padding: 15px 12px;
    margin: 0;
    word-break: normal;
    display: block;
    overflow-x: auto;
    color: #333;
    background: #f8f8f8
  }

  .markdown-body a {
    text-decoration: none;
    color: #0269c8;
    border-bottom: 1px solid #d1e9ff
  }

  .markdown-body a:active, .markdown-body a:hover {
    color: #275b8c
  }

  .markdown-body table {
    display: inline-block !important;
    font-size: 12px;
    width: auto;
    max-width: 100%;
    overflow: auto;
    border: 1px solid #f6f6f6
  }

  .markdown-body thead {
    background: #f6f6f6;
    color: #000;
    text-align: left
  }

  .markdown-body tr:nth-child(2n) {
    background-color: #fcfcfc
  }

  .markdown-body td, .markdown-body th {
    padding: 12px 7px;
    line-height: 24px
  }

  .markdown-body td {
    min-width: 120px
  }

  .markdown-body blockquote {
    color: #666;
    padding: 1px 23px;
    margin: 22px 0;
    border-left: 4px solid #cbcbcb;
    background-color: #f8f8f8
  }

  .markdown-body blockquote:after {
    display: block;
    content: ""
  }

  .markdown-body blockquote > p {
    margin: 10px 0
  }

  .markdown-body ol, .markdown-body ul {
    padding-left: 28px
  }

  .markdown-body ol li, .markdown-body ul li {
    margin-bottom: 0;
    list-style: inherit
  }

  .markdown-body ol li .task-list-item, .markdown-body ul li .task-list-item {
    list-style: none
  }

  .markdown-body ol li .task-list-item ol, .markdown-body ol li .task-list-item ul, .markdown-body ul li .task-list-item ol, .markdown-body ul li .task-list-item ul {
    margin-top: 0
  }

  .markdown-body ol ol, .markdown-body ol ul, .markdown-body ul ol, .markdown-body ul ul {
    margin-top: 3px
  }

  .markdown-body ol li {
    padding-left: 6px
  }

  .markdown-body .contains-task-list {
    padding-left: 0
  }

  .markdown-body .task-list-item {
    list-style: none
  }

  @media (max-width: 720px) {
    .markdown-body h1 {
      font-size: 24px
    }

    .markdown-body h2 {
      font-size: 20px
    }

    .markdown-body h3 {
      font-size: 18px
    }
  }
</style>