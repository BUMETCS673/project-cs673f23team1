<template>
  <a-form :form="form" :label-col="{ span: 5 }" :wrapper-col="{ span: 17 }" @submit="handleSubmit">

    <a-form-item :label="$t('common.labelName')">
      <a-input v-decorator="['labelName', validatorRules.label]"
               :placeholder="$t('common.pleaseLabel')"/>
    </a-form-item>

    <a-form-item :label="$t('common.labelLogo')">
      <ImageUpload
          ref="child"
          :labelLogo="labelLogo"
          @labelLogoFn="labelLogoFn"/>
    </a-form-item>
    <a-divider style="margin: 10px 0;"></a-divider>
    <a-form-item class="form-item-submit">
      <a-button type="primary" html-type="submit">{{ $t('common.sureAndAdd') }}</a-button>
    </a-form-item>
  </a-form>
</template>

<script>
import labelService from "@/service/labelService";
import ImageUpload from "@/components/label/ImageUpload";

export default {
  components: {ImageUpload},

  props: {
    labelId: {type: Number, default: 0},
    labelName: {type: String, default: ''},
    labelLogoInit: {type: String, default: null},
  },

  data() {
    return {
      labelLogo: this.labelLogoInit,
      form: this.$form.createForm(this, {name: 'coordinated'}),
      validatorRules: {
        label: {
          rules: [
            {required: true, message: this.$t('common.pleaseLabel')}
          ]
        }
      }
    }
  },

  methods: {
    handleSubmit(e) {
      e.preventDefault();

      this.form.validateFields((err, values) => {
        if (!err) {
          const data = {
            "logo": this.labelLogo,
            "labelName": values.labelName
          };
          if (this.labelLogo) {
            if (this.labelId) {
              data.id = this.labelId;
              this.labelUpdate(data);
            } else {
              this.labelCreate(data);
            }
          } else {
            this.$message.warning('Please upload Logo');
          }
        }
      });
    },

    labelCreate(data) {
      labelService.labelCreate(data)
          .then(res => {
            this.form.resetFields();
            this.$refs.child.clearFileList();
            this.$emit("hideLabelVisibleFn");
            this.refresh();
          })
          .catch(err => {
            this.$message.error(err.desc);
          });
    },

    labelUpdate(data) {
      labelService.labelUpdate(data)
          .then(res => {
            this.$emit("hideLabelVisibleFn", data.id);
            this.refresh();
          })
          .catch(err => {
            this.$message.error(err.desc);
          });
    },

    labelLogoFn(logo) {
      this.labelLogo = logo;
    },

    refresh() {
      this.$emit("refresh");
    },
  },

  mounted() {
    this.form.setFieldsValue({
      labelName: this.labelName,
    })
  }

}
</script>

<style scoped>
.form-item-submit {
  display: flex;
  text-align: right;
  justify-content: right;
  margin-bottom: 0;
}
</style>