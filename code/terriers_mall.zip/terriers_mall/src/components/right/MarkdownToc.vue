<template>
  <div id="markdown-toc" :style="top ? 'position: fixed; z-index: 888;top: 64px;width: 275px;' : ''">
    <header class="post-toc-header">
      {{ $t("common.toc") }}
    </header>
    <a-divider style="margin: 10px 0 0 0;"/>
    <div class="toc-content" v-html="postHtml"></div>
  </div>
</template>

<script>
export default {
  name: "MarkdownToc",

  props: {
    postHtml: {type: String, default: ''},
  },

  data() {
    return {
      top: false,
    }
  },

  methods: {
    handleScroll(el) {
      el.onscroll = ({target}) => {

        const {scrollTop, scrollHeight, clientHeight} = target;

        if (scrollTop > 850) {
          this.top = true;
        } else {
          this.top = false;
        }
      };
    }
  },

  mounted() {
    this.handleScroll.call(this, document.querySelector('#app'));
  },

}
</script>

<style lang="less" scoped>
#markdown-toc {
  padding-bottom: 10px;

  .toc-content {
    max-height: 700px;
    overflow: auto;
  }
}

#markdown-toc .post-toc-header {
  padding: 15px 10px 0 15px;
}

#markdown-toc {
  /deep/ * {
    .catalog-list {
      font-weight: 600;
      position: relative;
      font-size: 15px;
    }

    & > li > a {
      position: relative;
      padding-left: 15px;
      line-height: 20px;
    }

    ul, li {
      padding: 0;
      margin: 0;
      list-style: none;
    }

    /* h1 */
    ul > li > a {
      font-size: 14px;
      color: #333333;
      padding-left: 15px;
      font-weight: 500;
      position: relative;
    }
    /* h2 */
    ul > ul > li > a {
      line-height: 20px;
      font-size: 14px;
      color: #333333;
      padding-left: 30px;
      font-weight: normal;
    }
    /* h3 */
    ul > ul > ul > li > a {
      line-height: 20px;
      font-size: 14px;
      color: #333333;
      padding-left: 45px;
      font-weight: normal;
    }
    /* h4 */
    ul > ul > ul > ul > li > a {
      line-height: 20px;
      font-size: 14px;
      color: #333333;
      padding-left: 60px;
      font-weight: normal;
    }
    /* h5 */
    ul > ul > ul > ul > ul > li > a {
      line-height: 20px;
      font-size: 14px;
      color: #333333;
      padding-left: 75px;
      font-weight: normal;
    }
    /* h6 */
    ul > ul > ul >ul > ul > ul > li > a {
      line-height: 20px;
      font-size: 14px;
      color: #333333;
      padding-left: 90px;
      font-weight: normal;
    }

    ul > .active > a {
      color: #0366d6;
      font-size: 18px;
      font-weight: 900;
    }

    a {
      color: #000;
      display: block;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      padding: 6px 0;

      &:hover {
        background-color: #8b87870a;
      }
    }
  }
}
</style>