<template>
  <div class="footer-buttons">
    <BackTop/>
    <a-tooltip placement="left">
      <template slot="title">
        {{ $t("common.feedback") }}
      </template>
      <div @click="createFeedback" class="feedback-icon-container" style="background: #fff">
        <i class="iconfont icon-bug" style="color: red"></i>
      </div>
    </a-tooltip>
    <a-tooltip placement="left">
      <template slot="title">
        {{ $t("common.chat") }}
      </template>
      <div @click="routerChat" class="chat-icon-container" style="background: #fff">
        <i class="iconfont icon-chat" style="color: #2d9d92"></i>
      </div>
    </a-tooltip>    
  </div>
</template>

<script>
import BackTop from "@/components/utils/BackTop";

export default {
  components: {BackTop},
  methods: {
    createFeedback() {
      if (this.$store.state.isLogin) {
        window.open(this.$store.state.manageDomain + '/createFeedback', '_blank');
      } else {
        this.$store.state.loginVisible = true;
      }
    },

    // There should be link for a chat room here for all users and developers to chat directly, but we dont have enough time to finish it, sorry
    routerChat() {
      window.open('', '_blank');
    },

  }
};
</script>

<style lang="less">
.footer-buttons {
  position: fixed;
  bottom: 3.6rem;
  right: 6.6rem;
  z-index: 888;

  .feedback-icon-container, .chat-icon-container {
    border-radius: 50%;
    width: 34px;
    height: 34px;
    text-align: center;
    cursor: pointer;

    i {
      line-height: 34px;
      color: white;
    }
  }

  .chat-icon-container {
    margin-top: 10px;
  }
}
</style>
