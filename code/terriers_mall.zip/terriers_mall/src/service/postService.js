import axios from "axios";

export default {
    
    getPostList(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/posts/getList", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },
    
    getPersonalPosts(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/posts/getPersonalPosts", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },
   
    getPendingReviewPosts(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/posts/getPendingReviewPosts", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    getDisabledPosts(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/posts/getDisabledPosts", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },
 
    updateState(data) {
        return new Promise((resolve, reject) => {
            axios.post("/api/bbs/posts/updateState", data)
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },
 
    getLikesPost(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/posts/getLikesPost", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },
  
    getPostCommentVisitTotal(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/posts/getPostCommentVisitTotal", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },
    //upload picture(one picture)
    uploadPicture(data) {
        return new Promise((resolve, reject) => {
            axios.post("/api/bbs/posts/uploadPicture", data)
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    postCreate(data) {
        return new Promise((resolve, reject) => {
            axios.post("/api/bbs/posts/create", data)
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    postUpdate(data) {
        return new Promise((resolve, reject) => {
            axios.post("/api/bbs/posts/update", data)
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    getPostById(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/posts/getById", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    getPostCountById(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/posts/getCountById", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    postTop(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/posts/postTop", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },
  
    postDelete(data) {
        return new Promise((resolve, reject) => {
            axios.post("/api/bbs/posts/delete/" + data)
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    getPostCheckCount(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/posts/getPostCheckCount", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    getGoods(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/posts/getGoods", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },
};
