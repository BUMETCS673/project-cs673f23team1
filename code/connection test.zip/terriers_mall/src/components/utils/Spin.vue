<template>
  <div style="text-align: center;">
    <!-- If it is still rendering after 1s, show "Loading..."" -->
    <a-spin tip="Loading..." :spinning="spinning" :delay="1000" style="padding-top: 150px"/>
  </div>
</template>


<script>
export default {
  props: {
    spinning: {type: Boolean, default: false},
  },
}
</script>

<style scoped>

</style>