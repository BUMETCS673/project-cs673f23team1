<template>
  <a-modal
      :centered="true"
      :title="null"
      :destroyOnClose="true"
      :maskClosable="true"
      width="360px"
      @cancel="handleCancel"
      :visible="visible"
      :footer="null"
  >
    <p class="title">{{ $t("common.editAvatar") }}</p>
    <p class="tip">{{ $t("common.avatarTip")[0] }}</p>
    <p class="tip">{{ $t("common.avatarTip")[1] }}</p>
    <div class="progress">
      <a-progress v-if="progress > 0" :percent="progress"/>
    </div>
    <div class="img-container">
      <label for="avatarFile">
        <img
            v-if="!picture"
            style="width: 100%"
            src="@/assets/img/avatar-bg.png"
            alt=""
        />
        <img v-else style="width: 100%" :src="picture" alt=""/>
      </label>
      <input
          style="display: none"
          accept=".jpg, .jpeg, .png"
          @change="onFileChange"
          type="file"
          name="avatarFile"
          id="avatarFile"
      />
    </div>
    <div class="footer">
      <a-button @click="handleOk" :loading="loading" type="primary">{{
          $t("common.save")
        }}
      </a-button>
    </div>
  </a-modal>
</template>

<script>
import userService from "@/service/userService";

export default {
  props: {
    visible: {type: Boolean, default: false},
  },

  data() {
    return {
      loading: false,
      picture: this.$store.state.picture,
      file: "",
      progress: 0,
    };
  },
  methods: {

    onFileChange(e) {
      this.file = e.target.files[0];
      this.picture = window.URL.createObjectURL(this.file);
    },

    handleOk() {

      if (
          !this.picture ||
          this.picture === this.$store.state.picture
      ) {
        this.$message.warning(this.$t("common.noPictureTip"));
        return;
      }

      if (this.file.size > 5 * 1024 * 1024) {
        this.$message.warning(this.$t("common.avatarSizeTip"));
        return;
      }
      const file = new FormData();
      file.append("picture", this.file);
      this.loading = true;
      userService.uploadUserPicture(file, this.onUploadProgress.bind(this))
          .then(() => {
            this.$message.success(this.$t("common.uploadSuccessed"));
            this.handleCancel();
            this.$emit("refresh");
            this.loading = false;
          })
          .catch((err) => {
            this.progress = 0;
            this.$message.error(err.desc);
            this.loading = false;
          });
    },


    onUploadProgress({loaded, total}) {
      this.progress = ((loaded / total) * 100).toFixed(2) - 0;
    },


    handleCancel() {
      this.progress = 0;
      this.loading = false;

      this.$emit("closeModal");
    },
  },

  watch: {
    visible: function () {
      this.picture = this.$store.state.picture;
    },
  },
};
</script>

<style lang="less" scoped>
.title {
  margin: 16px 32px 12px;
  font-size: 24px;
  font-weight: 500;
  color: #121212;
  text-align: center;
}

.tip {
  text-align: center;
  margin-bottom: 0px;
  color: rgb(161, 63, 63);
}

.progress {
  height: 20px;
  margin: 10px;
  margin-bottom: 0;
}

.img-container {
  padding: 0 10px;

  img {
    cursor: pointer;
  }
}

.footer {
  padding: 32px 10px 0;
  text-align: center;

  button {
    width: 100%;
    height: 36px;
    font-size: 16px;
  }
}
</style>
