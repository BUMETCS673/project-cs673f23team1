import axios from "axios";

export default {
  //get label
  getLabelList(params) {
    return new Promise((resolve, reject) => {
      axios.get("/api/bbs/label/getList", {params})
          .then((res) => resolve(res))
          .catch((err) => reject(err));
    });
  },
  // upload logo of label
  uploadLabelLogo(data) {
    return new Promise((resolve, reject) => {
      axios.post("/api/bbs/label/uploadLabelLogo", data)
          .then((res) => resolve(res))
          .catch((err) => reject(err));
    });
  },
  // add label
  labelCreate(data) {
    return new Promise((resolve, reject) => {
      axios.post("/api/bbs/label/create", data)
          .then((res) => resolve(res))
          .catch((err) => reject(err));
    });
  },
  // update label
  labelUpdate(data) {
    return new Promise((resolve, reject) => {
      axios.post("/api/bbs/label/update", data)
          .then((res) => resolve(res))
          .catch((err) => reject(err));
    });
  },
  // delete label
  labelDelete(data) {
    return new Promise((resolve, reject) => {
      axios.post("/api/bbs/label/delete/" + data)
          .then((res) => resolve(res))
          .catch((err) => reject(err));
    });
  },

};
