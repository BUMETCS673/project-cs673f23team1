<template>
  <div id="post-check" :style="$store.state.collapsed ? 'left: 2%;' : ''">
    <!-- pass -->
    <div class="enable-div">
      <a-badge class="badge" :count="data.enableCount" :overflow-count="999" :number-style="{
        backgroundColor: '#07c19a',
        boxShadow: '0 0 0 0 #fff inset',
      }">
        <div class="icon-container" @click="postCheck('enable')"
             :style="$store.state.postCheck === 'enable' ?
             {'background': '#000', 'box-shadow':  '10px 10px 19px #489dcf, -2px -2px 19px #62d5ff'} : ''">
          <a-icon type="check-circle" style="color: #07c19a"/>
        </div>
      </a-badge>
    </div>

    <!-- reject -->
    <div class="disabled-div">
      <a-badge class="badge" :count="data.disabledCount" :overflow-count="999" :number-style="{
        backgroundColor: 'red',
        boxShadow: '0 0 0 0 #fff inset',
      }">
        <div class="icon-container" @click="postCheck('disabled')"
             :style="$store.state.postCheck === 'disabled' ?
             {'background': '#000', 'box-shadow':  '10px 10px 19px #489dcf, -2px -2px 19px #62d5ff'} : ''">
          <a-icon type="close-circle" style="color: red"/>
        </div>
      </a-badge>
    </div>

    <!-- waiting for -->
    <div class="pendingReview-div">
      <a-badge class="badge" :count="data.pendingReviewCount" :overflow-count="999" :number-style="{
        backgroundColor: '#faad14',
        boxShadow: '0 0 0 0 #fff inset',
      }">
        <div class="icon-container" @click="postCheck('pendingReview')"
             :style="$store.state.postCheck === 'pendingReview' ?
              {'background': '#000', 'box-shadow':  '10px 10px 19px #489dcf, -2px -2px 19px #62d5ff'} : ''">
          <a-icon type="pause-circle" style="color: #faad14;"/>
        </div>
      </a-badge>
    </div>

  </div>
</template>

<script>

import postService from "@/service/postService";

export default {

  data() {
    return {
      data: {},
    }
  },

  methods: {
    
    getPostCheckCount() {
      postService.getPostCheckCount({title: this.$route.query.query})
          .then((res) => {
            this.data = res.data;
          })
          .catch(err => {
            this.$message.error(err.desc);
          });
    },

    postCheck(value) {
      this.$store.state.postCheck = value;
      this.$emit("initPosts")
    },
  },

  mounted() {
    this.getPostCheckCount();
  }
};
</script>

<style lang="less">
#post-check {
  position: fixed;
  z-index: 888;

  .icon-container {
    border-radius: 50%;
    width: 45px;
    height: 45px;
    text-align: center;
    cursor: pointer;
    background: #fff;

    i {
      font-size: 20px;
      line-height: 50px;
    }

  }

  .icon-container:hover {
    box-shadow:  10px 10px 19px #489dcf, -2px -2px 19px #62d5ff;
  }

  .disabled-div, .pendingReview-div {
    margin-top: 20px;
  }

}
</style>
