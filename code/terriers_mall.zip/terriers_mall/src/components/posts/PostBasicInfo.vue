<template>
  <div id="post-basic-info">
    <a-form :form="form" :label-col="{ span: 5 }" :wrapper-col="{ span: 17 }" @submit="handleSubmit">
      <!-- add label -->
      <a-form-item :label="$t('common.addLabel')">
        <a-select mode="multiple"
                  v-decorator="['lableId', validatorRules.label]"
                  :placeholder="$t('common.selectLabel')"
                  @change="handleSelectChange">
          <a-select-option v-for="item of listData" :key="item.id">
            {{ item.labelName }}
          </a-select-option>
        </a-select>
      </a-form-item>
      <!-- post cover -->
      <a-form-item :label="$t('common.postCover')">
        <UploadImage
            :postTitleMap="postTitleMap"
            @titleMap="titleMap"/>
      </a-form-item>
      <a-divider style="margin: 10px 0;"></a-divider>
      <a-form-item class="form-item-submit">
        <a-button type="primary" html-type="submit">
          {{ $route.params.id ? $t('common.sureAndUpdate') : $t('common.sureAndRelease') }}
        </a-button>
      </a-form-item>
    </a-form>
  </div>
</template>

<script>
import labelService from "@/service/labelService";
import postService from "@/service/postService";
import UploadImage from "@/components/posts/UploadImage";

export default {
  components: {UploadImage},

  props: {
    // post creater
    postUser: {type: Number, default: 0},
    // post label
    postLabel: {type: Array, default: []},
    // picture of post title
    postTitleMap: {type: String, default: ""},
  
    postTitle: {type: String, default: ""},
    // post content
    markdownCode: {type: String, default: ""},
    htmlCode: {type: String, default: ""},
  },

  data() {
    return {
      // title picture
      postFile: null,
      // label
      listData: [],
      params: {currentPage: 1, pageSize: 10},
      form: this.$form.createForm(this, {name: 'coordinated'}),
      
      validatorRules: {
        label: {
   
          rules: [
              
              { required: true, message: this.$t('common.selectLabel') }
          ]
        }
      }
    }
  },

  methods: {
    handleSubmit(e) {
      e.preventDefault();

      if (this.postTitle.length === 0) {
        this.$message.warning("Title can not be empty");
        return;
      }

      if (this.htmlCode.length === 0 || this.markdownCode.length === 0) {
        this.$message.warning("Content can not be empty");
        return;
      }

      // Check picture size(should be less than 5M)
      if (this.postFile !== null && this.postFile.size > 5 * 1024 * 1024) {
        this.$message.warning(this.$t("common.avatarSizeTip"));
        return;
      }

      this.form.validateFields((err, values) => {
        if (!err) {
          const data = new FormData();
          data.append("file", this.postFile);
          data.append("title", this.postTitle);
          data.append("markdown", this.markdownCode);
          data.append("html", this.htmlCode);
          data.append("labelIds", values.lableId);

          let postId = this.$route.params.id;
          if (postId) {
            data.append("id", postId);
            this.postUpdate(data);
          } else {
            this.postCreate(data);
          }
        }
      });
    },

    handleSelectChange(value) {
      if (value.length > 3) {
        this.$message.warning("You can add at most 3 labels");
        value.splice(-1);
      }
    },

    getLabelList(params) {
      labelService.getLabelList(params)
          .then(res => {
            this.listData = res.data.list;
          })
          .catch(err => {
            this.$message.error(err.desc);
          });
    },

    // Create a post
    postCreate(data) {
      postService.postCreate(data)
          .then(res => {
            this.$router.push("/user/" + this.$store.state.userId + "/post");
          })
          .catch(err => {
            this.$message.error(err.desc);
          });
    },

    // update a post
    postUpdate(data) {
      if (this.$store.state.userId !== this.postUser) {
        this.$message.warning("You don't have access to modify other's post");
        return;
      }
      postService.postUpdate(data)
          .then(res => {
            // go back
            this.$router.go(-1);
          })
          .catch(err => {
            this.$message.error(err.desc);
          });
    },

    titleMap(file) {
      this.postFile = file;
    },
  },

  mounted() {
    this.params.pageSize = 100;
    this.getLabelList(this.params);
    // v-mode and v-decorator will be conflict, this method can solve it
    this.form.setFieldsValue({
      lableId: this.postLabel,
    })
  }
}
</script>

<style>

#post-basic-info .form-item-submit {
  display: flex;
  text-align: right;
  justify-content: right;
  margin-bottom: 0;
}
</style>