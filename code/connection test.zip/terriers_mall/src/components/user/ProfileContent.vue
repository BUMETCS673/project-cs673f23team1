<template>
  <div id="profile-content" v-if="!spinning">
    <a-col :span="$store.state.collapsed ? 24 :18" style="background: #fff;">
      <div class="left">
        <a-form-model ref="ruleForm" :model="ruleForm" :rules="rules" v-bind="layout" labelAlign="left">
          <p>{{ $t('common.personalInformation') }}</p>
          <a-divider/>

          <a-form-model-item has-feedback prop="username" :label="$t('common.username2')">
            <a-input v-model="ruleForm.username"
                     :maxLength="$store.state.userMaxLength"
                     :suffix="ruleForm.userNameNum + '/' + $store.state.userMaxLength"
                     @change="usernameChange"
                     autocomplete="off"
                     :placeholder="$t('common.fillInYourUsername')"/>
          </a-form-model-item>

          <a-form-model-item has-feedback prop="major" :label="$t('common.major')">
            <a-input v-model="ruleForm.major"
                     :suffix="ruleForm.majorNum + '/50'"
                     @change="commonChange"
                     :maxLength="50"
                     :placeholder="$t('common.fillInYourMajor')"/>
          </a-form-model-item>

          <a-form-model-item has-feedback prop="college" :label="$t('common.college')">
            <a-input v-model="ruleForm.college"
                     :suffix="ruleForm.collegeNum + '/50'"
                     @change="commonChange"
                     :maxLength="50"
                     :placeholder="$t('common.fillInYourCollege')"/>
          </a-form-model-item>

          <a-form-model-item has-feedback prop="intro" :label="$t('common.selfIntro')">
            <a-textarea v-model="ruleForm.intro"
                        :suffix="ruleForm.introNum + '/150'"
                        @change="commonChange"
                        :maxLength="150"
                        :placeholder="$t('common.fillInYour7788')"
                        :auto-size="{ minRows: 5, maxRows: 8 }"
                        class="intro"/>
          </a-form-model-item>

          <a-form-model-item>
            <a-divider style="margin: 10px 0;"></a-divider>
            <a-form-item class="form-item-submit">
              <a-button type="primary" html-type="submit" @click="submitForm('ruleForm')">
                {{ $t('common.saveChanges') }}
              </a-button>
            </a-form-item>
          </a-form-model-item>
        </a-form-model>
      </div>
    </a-col>
    <a-col :span="$store.state.collapsed ? 24 :6" style="background: #fff;">
      <div class="right">
        <a-col class="avatar-col">
          <div class="avatar">
            <div @click="openUploadModal" class="avatar-container">
              <a-avatar
                  v-if="true"
                  style="cursor: pointer" :size="120" icon="user"
                  :src="$store.state.picture ? $store.state.picture : require('@/assets/img/default_avatar.png')"/>
              <img
                  v-else
                  src="@/assets/img/default_avatar.png"
                  width="120"
                  style="border-radius: 50%"/>
              <div class="avatar-wrapper">
                <a-icon style="font-size: 38px" type="plus-circle"/>
                <span style="line-height: 40px">{{
                    $t("common.clickToChangeAvatar")
                  }}</span>
              </div>
            </div>
          </div>
          <div class="avatar-tip">
            <div>{{ $t("common.avatarTip")[0] }}</div>
            <div>{{ $t("common.avatarTip")[1] }}</div>
          </div>
        </a-col>
        <UploadModal
            :visible="visible"
            @closeModal="closeModal"
            @refresh="refresh"/>
      </div>
    </a-col>
  </div>
</template>

<script>
import UploadModal from "@/components/user/UploadModal";
import userService from "@/service/userService";

export default {
  name: "ProfileContent",

  components: {UploadModal},

  data() {

    let validateUsername = (rule, value, callback) => {
      if (value === '') {
        callback(new Error(this.$t('common.pleaseInputYourUsername')));
      } else {
        this.isValidUser(value)
            .then(() => {
              callback();
            })
            .catch(err => {
              callback(err.desc);
            });
      }
    };

    return {
      urlReg: /^(?=^.{3,255}$)(http(s)?:\/\/)?(www\.)?[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+(:\d+)*(\/\w+\.\w+)*$/,

      spinning: true,
      visible: false,

      ruleForm: {
        userId: this.$store.state.userId,
        username: '',
        userNameNum: 0,

        major: '',
        majorNum: 0,

        company: '',
        companyNum: 0,

        intro: '',
        introNum: 0,

        orgId: Number,
      },
      rules: {
        username: [{validator: validateUsername, trigger: 'change'}],        
      },
      layout: {
        labelCol: {span: this.$store.state.collapsed ? 24 : 3},
        wrapperCol: {span: this.$store.state.collapsed ? 24 : 21},
      },
    }
  },

  methods: {

    getUserInfo() {
      userService.getUserInfo({userId: this.ruleForm.userId})
          .then(res => {
            this.spinning = false;
            this.ruleForm.username = res.data.name,
                this.ruleForm.userNameNum = res.data.name.length;

            this.ruleForm.major = res.data.major ? res.data.major : '';
            this.ruleForm.majorNum = res.data.major ? res.data.major.length : 0;

            this.ruleForm.college = res.data.college ? res.data.college : '';
            this.ruleForm.collegeNum = res.data.college ? res.data.college.length : 0;

            this.ruleForm.intro = res.data.intro;
            this.ruleForm.introNum = res.data.intro ? res.data.intro.length : 0;

            this.ruleForm.orgId = res.data.orgId;
          })
          .catch(err => {
            this.$message.error(err.desc);
          });
    },


    updateUserBasicInfo(data) {
      userService.updateUserBasicInfo(data)
          .then(res => {
            this.$message.success(this.$t('common.saveSuccessed'));
            this.getUserInfo();
          })
          .catch(err => {
            this.$message.error(err.desc);
          });
    },

    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          const data = {
            name: this.ruleForm.username,
            major: this.ruleForm.major,
            college: this.ruleForm.college,
            intro: this.ruleForm.intro,
            orgId: this.ruleForm.orgId,
          };
          this.updateUserBasicInfo(data);
        } else {
          return false;
        }
      });
    },

    usernameChange(value) {
      this.ruleForm.userNameNum = value.target.value.length;
    },
    commonChange() {
      this.ruleForm.majorNum = this.ruleForm.major.length;
      this.ruleForm.collegeNum = this.ruleForm.college.length;
      this.ruleForm.introNum = this.ruleForm.intro.length;
    },


    isValidUser(username) {
      return new Promise((resolve, reject) => {
        userService.isValidUser({username: username})
            .then(res => {
              if (res.code === 0) {
                resolve(res);
              } else {
                throw res;
              }
            })
            .catch(err => {
              reject(err);
            });
      });
    },

    refresh() {
      this.getUserInfo();
    },


    openUploadModal() {
      this.visible = true;
    },


    closeModal() {
      this.visible = false;
    },


    routerFrontPage() {
      this.$router.push("/");
    },
  },

  mounted() {
    if (this.ruleForm.userId) {
      this.getUserInfo();
    } else {
      this.routerFrontPage();
    }
  }

}
</script>

<style lang="less">
#profile-content {
  background: #fff;

  .left {
    padding: 30px;

    p {
      font-weight: 600;
      font-size: 20px;
      line-height: 18px;
      color: #333;
    }
  }
}

#profile-content .avatar-col {
  .avatar {
    margin-top: 60px;
    height: 120px;
    display: flex;
    justify-content: center;
    align-items: center;

    .avatar-container {
      cursor: pointer;
      position: relative;
      height: 120px;
      width: 120px;
      text-align: center;

      .avatar-wrapper {
        display: none;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        color: white;
        position: absolute;
        top: 0;
        border-radius: 50%;
        width: 120px;
        height: 120px;
        background-color: rgba(29, 33, 41, 0.5);
      }
    }

    .avatar-container:hover {
      .avatar-wrapper {
        display: flex;
      }
    }
  }

  .avatar-tip {
    text-align: center;
    padding: 24px 0;
    color: #86909c;
  }
}

#profile-content .ant-input {
  padding-right: 50px;
}
#profile-content .homePage .ant-input {
  padding-right: 70px;
}
#profile-content textarea.intro.ant-input {
  padding-right: 0!important;
}
</style>