<template>
  <div id="create-post-index">
    <CreatePost />
  </div>
</template>

<script>
    import CreatePost from "@/components/posts/CreatePost";

    export default {
        components: {CreatePost},

    }
</script>

<style>
  #create-post-index {
    height: 100%;
  }
</style>