<template>
  <div class="header-left-content">
    <a-menu v-model="current" :mode="$store.state.collapsed ? 'inline' : 'horizontal'">

      <a-menu-item key="frontPage" @click="refresh">{{ $t("common.home") }}</a-menu-item>
      <a-menu-item key="frontPost" @click="routerPost">{{ $t("common.post") }}</a-menu-item>

      <a-menu-item key="boilingPoint" @click="routerLabel">{{ $t("common.label") }}</a-menu-item>

      <a-menu-item key="liveStreaming" @click="routerResource">{{ $t("common.resource") }}</a-menu-item>

      <a-menu-item key="authorList" @click="routerAuthorList" v-if="$store.state.collapsed">{{ $t("common.authorList") }}</a-menu-item>

      <a-menu-item key="commentDonate" @click="routerCommentDonate" v-if="$store.state.collapsed">{{ $t("common.commentDonate") }}</a-menu-item>

      <a-menu-item key="createPost" @click="routerCreatePost" v-if="$store.state.collapsed">{{ $t("common.createPost") }}</a-menu-item>
      <a-divider style="margin: 3px 0 3px 0" v-if="$store.state.collapsed"/>

      <a-menu-item key="management" @click="routerManagement" v-if="$store.state.collapsed">{{ $t("common.management") }}</a-menu-item>
      
    </a-menu>
  </div>
</template>

<script>
 export default {
    name: "",

    data() {
      return {
        current: ['frontPage'],
      }
    },

    methods: {
      
      refresh() {
        this.$router.push('/');
      },

      routerPost() {
        this.$router.push("/post");
      },

      routerLabel() {
        this.$router.push("/label");
      },

      routerResource() {
        this.$router.push("/resource");
      },

      routerAuthorList() {
        this.$router.push("/recommended");
      },

      routerCreatePost() {
        this.$router.push("/post");
      },

      routerManagement() {
        window.open(this.$store.state.manageDomain, '_blank');
      },
     
    },

    mounted() {
      let name = this.$route.name;

      // clear array
      this.current.pop();
      // home page
      if (name === 'home') {
        // add new
        this.current.push('frontPage');
      }
      // post
      if (name === 'post') {
        // add new
        this.current.push('frontPost');
      }
      // label
      if (name === 'label') {
        // add new
        this.current.push('boilingPoint');
      }
      // Resource
      if (name === 'resource') {
        // add new
        this.current.push('liveStreaming');
      }
    },
  }
</script>

<style lang="less" scoped>
  .header-left-content {
    display: flex;
    justify-content: left;
    align-items: center;
  }

  
  .ant-menu-horizontal {
    border-bottom: 0;
  }

  .ant-menu-horizontal > .ant-menu-item-active, .ant-menu-horizontal > .ant-menu-item-open, .ant-menu-horizontal > .ant-menu-item-selected, .ant-menu-horizontal:not(.ant-menu-dark) > .ant-menu-item:hover, .ant-menu-horizontal > .ant-menu-submenu-active, .ant-menu-horizontal > .ant-menu-submenu-open, .ant-menu-horizontal:not(.ant-menu-dark) > .ant-menu-submenu-selected, .ant-menu-horizontal:not(.ant-menu-dark) > .ant-menu-submenu {
    border-bottom: 2px solid transparent;
  }
 
  .ant-menu-item, .ant-menu-submenu-title {
    padding: 0 16px;
  }
  
  .ant-menu-inline {
    border-right: 0;
  }
 
  .ant-menu-inline .ant-menu-item::after, .ant-menu-vertical .ant-menu-item::after, .ant-menu-vertical-left .ant-menu-item::after, .ant-menu-vertical-right .ant-menu-item::after {
    border-right: 3px solid transparent;
  }
  
  .ant-menu:not(.ant-menu-horizontal) .ant-menu-item-selected {
    background-color: transparent;
  }

</style>