import Vue from 'vue'
import VueRouter from 'vue-router'

const originalPush = VueRouter.prototype.push;
VueRouter.prototype.push = function push(location) {
    return originalPush.call(this, location).catch(err => err);
};

Vue.use(VueRouter)

const routes = [
    {
        path: "/",
        name: "home",
        component: () => import("@/components/index/GoodsIndex"),
    },
    {
        path: "/post",
        name: "post",
        component: () => import("@/components/index/Index"),
    },
    {
        path: "/search",
        component: () => import("@/components/index/Index"),
    },
    {
        path: "/recommended",
        name: "recommended",
        component: () => import("@/components/index/AuthorsListIndex"),
    },
    {
        path: "/create",
        component: () => import("@/components/index/CreatePostIndex"),
    },
    {
        path: "/edit/:id",
        component: () => import("@/components/index/CreatePostIndex"),
    },
    {
        path: "/detail/:id",
        name: "detail",
        component: () => import("@/components/index/PostDetailIndex"),
    },
    {
        path: "/empty",
        component: () => import("@/components/utils/CustomEmpty"),
    },
    {
        path: "/user/:id",
        component: () => import("@/components/index/UserCenterIndex"),
        children: [
            {
                path: ":userCenterTab",
                component: () => import("@/components/index/UserCenterIndex")
            },
        ]
    },
    {
        path: "/label",
        name: "label",
        component: () => import("@/components/index/LabelIndex"),
    },
    {
        path: "/label/:id",
        component: () => import("@/components/index/LabelToPostIndex"),
    },
    {
        path: "/settings",
        component: () => import("@/components/index/SetUpIndex"),
        children: [
            {
                path: "",
                redirect: "profile"
            },
            {
                path: "profile",
                name: "profile",
                component: () => import("@/components/user/ProfileContent")
            },
            {
                path: "account",
                name: "account",
                component: () => import("@/components/user/AccountSettings")
            },
        ]
    },
    {
        path: "/resource",
        name: "resource",
        component: () => import("@/components/index/ResourceIndex"),
    },
    {
        path: "/book",
        name: "book",
        component: () => import("@/components/index/Book"),
    },
    {
        path: "/about",
        name: "about",
        component: () => import("@/components/index/About"),
    },
    {
        path: "/500",
        name: '500',
        component: () => import("@/components/errorPage/ServerError")
    },
    {
        // put content that matched under `$route.params.pathMatch` 
        path: "/:pathMatch(.*)*",
        name: '404',
        component: () => import("@/components/errorPage/NotFound")
    }
];

const router = new VueRouter({
    mode: "history",
    base: process.env.BASE_URL,
    routes
});

export default router;
