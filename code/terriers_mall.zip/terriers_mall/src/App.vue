<template>
  <a-config-provider :locale="lang[$store.state.locale]">
    <div v-if="$store.state.width" id="app">
      <router-view/>
    </div>
  </a-config-provider>
</template>

<script>
import {mapMutations} from "vuex";
import userService from "./service/userService";
import en_US from "ant-design-vue/lib/locale-provider/en_US";

export default {
  data() {
    return {
      lang: {
        en_US: en_US
      }
    };
  },
  methods: {
    ...mapMutations(["changeColor"]),

    getAccess() {
      userService.getCurrentUserAccess()
          .then(res => {
            /**
             * @function checkErrorPage 
             */
            this.checkErrorPage(res);
            if (res.code === 0) {
              this.$store.state.userId = res.data.userId;
              this.$store.state.isLogin = true;
              res.data.roles.forEach(data => {
                // if user is super admin
                if (data.grade === 'NS_SUPER_ADMIN_ROLE') {
                  this.$store.state.isManage = true;
                }
              })
            }
          })
          .catch((err) => {
            // this.$message.error(err.desc);
          });
    },

    
    initDom() {
      const that = this;
      //check size of page
      window.onload = setWidth;
      window.onresize = setWidth;

      function setWidth() {
        that.$store.state.width = window.innerWidth;
        that.$store.state.height = window.innerHeight;
        // 900/1050
        that.$store.state.collapsed = window.innerWidth < 1000;
        that.$store.state.collapsedMax = window.innerWidth < 1300;
      }
    },
    checkErrorPage() {
      
      if (this.$route.path === "/500") {
        this.$router.push({path: "/"});
      }
    },
    /**
     * @function setThemeColor 
     */
    setThemeColor() {
      let navLanguage = "en_US";
      this.$store.state.locale = localStorage.language ? localStorage.language : navLanguage;
      this.changeColor(localStorage.themeColor || "#13c2c2");
    },
    setIsCarousel() {

      if (Number(window.localStorage.isCarousel) === 0) {
        this.$store.state.isCarousel = 0;
      } else {
        this.$store.state.isCarousel = 1;
      }
    }
  },
  created() {
    this.setThemeColor();
    this.setIsCarousel();
  },
  mounted() {

    this.initDom();

    this.getAccess();
  }
};
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  height: 100%;
  margin: 0;
  padding: 0;
  overflow: auto;
  background-color: #f0f2f5;
}
</style>
