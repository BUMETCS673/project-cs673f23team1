import axios from "axios";

export default {
  
  getCommentByPostId(params) {
    return new Promise((resolve, reject) => {
      axios.get("/api/bbs/comment/getCommentByPostId", {params})
          .then((res) => resolve(res))
          .catch((err) => reject(err));
    });
  },
  
  getLatestComment(params) {
    return new Promise((resolve, reject) => {
      axios.get("/api/bbs/comment/getLatestComment", {params})
          .then((res) => resolve(res))
          .catch((err) => reject(err));
    });
  },

  createComment(data) {
    return new Promise((resolve, reject) => {
      axios.post("/api/bbs/comment/create", data)
          .then((res) => resolve(res))
          .catch((err) => reject(err));
    });
  },

  deleteComment(data) {
    return new Promise((resolve, reject) => {
      axios.post("/api/bbs/comment/delete/" + data)
          .then((res) => resolve(res))
          .catch((err) => reject(err));
    });
  },

};
