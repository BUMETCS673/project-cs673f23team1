const UglyfyJsPlugin = require("uglifyjs-webpack-plugin");
const CompressionPlugin = require("compression-webpack-plugin");
const createThemeColorReplacerPlugin = require("./src/config/config");
const vueConfig = {
    
    devServer: {
        // proxy: "http://bbs.localhost.com",
        disableHostCheck: true,
        port: 8082
    },
    
    css: {
        loaderOptions: {
            less: {
                lessOptions: {
                    modifyVars: {},
                    javascriptEnabled: true
                }
            }
        }
    },
    assetsDir: "static",
    productionSourceMap: false,
    
    configureWebpack: {
        optimization: {
            minimizer: [
                
                new UglyfyJsPlugin({
                    test: /\.js(\?.*)?$/i
                })
            ]
        },
        plugins: [
            
            new CompressionPlugin({
                algorithm: "gzip",
                test: /\.js$|\.html$|\.css$/, 
                filename: "[path].gz[query]", 
                minRatio: 1, 
                threshold: 10240, 
                deleteOriginalAssets: false 
            }),
           
            createThemeColorReplacerPlugin()
        ],
        
        externals: {
       
            "vue2-leaflet": "Vue2Leaflet",
            leaflet: "L"
        }
    }
};
module.exports = vueConfig;
