<template>
  <a-layout>
    <a-layout id="components-layout-basic">
      <IndexHeader class="header"
                   @refresh="refresh"
                   :searchContent="searchContent"/>
      <a-layout-content>
        <main class="content">
          <a-col :span="$store.state.collapsed ? 24 : 18"
                 :style="$store.state.collapsed ? '' : 'border-right: 20px solid #f0f2f5'">
                 <CustomEmpty v-if="spinning"/>
            <div v-else>
          
              <SlideShow v-if="!$store.state.collapsed && $store.state.isCarousel"/>
              <a-row v-if="!$store.state.collapsed && $store.state.isCarousel">
                <a-col :span="24" style="height: 2px;"/>
              </a-row>
              <div class="post-check-left-buttons"
                   :style="$store.state.collapsedMax ? '' : 'right:70px'"
                   v-if="$store.state.isManage">

                <PostCheck
                    ref="child"
                    @initPost="initPosts"/>
              </div>
           
              <FrontPagePost v-if="$store.state.isManage && !spinning"
                                :finish="finish"
                                :hasNext="hasNext"
                                :data="listData"
                                :isAdminAudit="true"
                                @updateData="updateData"
                                @postTopCallBack="postTopCallBack"
                                @refresh="refresh"
                                style="background: #fff;"/>
            
              <FrontPagePost v-if="!$store.state.isManage && !spinning"
                                :finish="finish"
                                :hasNext="hasNext"
                                :data="listData"
                                @refresh="refresh"
                                style="background: #fff;"/>
            </div>
          </a-col>
          <a-col v-if="!$store.state.collapsed" :span="6">
            
            <ProjectIntro style="background: #fff;"/>
            <a-row>
              <a-col :span="24" style="height: 10px;"/>
            </a-row>

            <AuthorsList style="background: #fff;"/>
            <a-row>
              <a-col :span="24" style="height: 10px;"/>
            </a-row>

            <LatestComment style="background: #fff;"/>
            <a-row>
              <a-col :span="24" style="height: 10px;"/>
            </a-row>

          </a-col>
        </main>
      </a-layout-content>
    </a-layout>
  </a-layout>
</template>

<script>
import IndexHeader from "@/components/index/head/IndexHeader";
import SlideShow from "@/components/concern/SlideShow";
import FrontPagePost from "@/components/posts/FrontPagePost";
import ProjectIntro from "@/components/right/ProjectIntro";
import postService from "@/service/postService";
import AuthorsList from "@/components/right/AuthorsList";
import CustomEmpty from "@/components/utils/CustomEmpty";
import LatestComment from "@/components/right/LatestComment";
import PostCheck from "@/components/posts/PostCheck";

export default {
  components: {
    IndexHeader,
    SlideShow,
    FrontPagePost,
    ProjectIntro,
    AuthorsList,
    CustomEmpty,
    LatestComment,
    PostCheck
  },
  data() {
    return {
      
      spinning: true,
      listData: [],
      hasNext: true,
      finish: false,
      params: {currentPage: 1, pageSize: 12},
      searchContent: '',
    };
  },

  methods: {
    
    loadMore() {
      this.params.currentPage++;
      if (this.$store.state.postCheck === 'enable') {
        this.getPostList(this.params, true);
      }
      if (this.$store.state.postCheck === 'pendingReview') {
        this.getPendingReviewPosts(this.params, true);
      }
      if (this.$store.state.postCheck === 'disabled') {
        this.getDisabledPosts(this.params, true);
      }
    },

    
    initPosts() {
      
      this.$nextTick(() => {
        let dom = document.querySelector('#app');
        if (dom !== null) {
          dom.scrollTop = 0;
        }
      })

      this.hasNext = true;
      if (this.$store.state.postCheck === "enable") {
        this.getPostList(this.params);
      }
      if (this.$store.state.postCheck === "pendingReview") {
        this.getPendingReviewPosts(this.params);
      }
      if (this.$store.state.postCheck === "disabled") {
        this.getDisabledPosts(this.params);
      }
    },

   
    getPostList(params, isLoadMore) {
      if (!isLoadMore) {
        this.params.currentPage = 1;
      }
      this.finish = false;
      postService.getPostList(params)
          .then(res => {
            if (isLoadMore) {
              this.listData = this.listData.concat(res.data.list);
              this.hasNext = res.data.list.length !== 0;
            } else {
              this.listData = res.data.list;
            }
            this.spinning = false;
            this.finish = true;
          })
          .catch(err => {
            this.finish = true;
            this.$message.error(err.desc);
          });
    },

  
    getPendingReviewPosts(params, isLoadMore) {
      if (!isLoadMore) {
        this.params.currentPage = 1;
      }
      this.finish = false;
      postService.getPendingReviewPosts(params)
          .then(res => {
            if (isLoadMore) {
              this.listData = this.listData.concat(res.data.list);
              this.hasNext = res.data.list.length !== 0;
            } else {
              this.listData = res.data.list;
            }
            this.spinning = false;
            this.finish = true;
          })
          .catch(err => {
            this.finish = true;
            this.$message.error(err.desc);
          });
    },


    getDisabledPosts(params, isLoadMore) {
      if (!isLoadMore) {
        this.params.currentPage = 1;
      }
      this.finish = false;
      postService.getDisabledPosts(params)
          .then(res => {
            if (isLoadMore) {
              this.listData = this.listData.concat(res.data.list);
              this.hasNext = res.data.list.length !== 0;
            } else {
              this.listData = res.data.list;
            }
            this.spinning = false;
            this.finish = true;
          })
          .catch(err => {
            this.finish = true;
            this.$message.error(err.desc);
          });
    },


    refresh() {
      this.params = {currentPage: 1, pageSize: 10};
      this.getPostList(this.params);
    },


    updateData(tempData) {
      this.listData = tempData;
      if (this.$store.state.isManage) {
     
        this.$refs.child.getPostCheckCount();
      }
    },

   
    postTopCallBack() {   
      this.$nextTick(() => {
        let dom = document.querySelector('#app');
        if (dom !== null) {
          dom.scrollTop = 0;
        }
      })

      if (this.$store.state.postCheck === "enable") {
        this.getPostList(this.params);
      }
      if (this.$store.state.postCheck === "pendingReview") {
        this.getPendingReviewPosts(this.params);
      }
      if (this.$store.state.postCheck === "disabled") {
        this.getDisabledPosts(this.params);
      }
    }
  },

  mounted() {

    this.$nextTick(() => {
      let dom = document.querySelector('#app');
      if (dom !== null) {
        dom.scrollTop = 0;
      }
    })

    let query = this.$route.query.query;
    this.searchContent = query;
    this.params.title = query;
    this.getPostList(this.params);
    this.$utils.scroll.call(this, document.querySelector('#app'));
  },

  watch: {
 
    $route() {
      let query = this.$route.query.query;
      this.searchContent = query;
      this.params.title = query;
      if (this.$store.state.isManage) {
        if (this.$store.state.postCheck === "enable") {
          this.getPostList(this.params);
        }
        if (this.$store.state.postCheck === "pendingReview") {
          this.getPendingReviewPosts(this.params);
        }
        if (this.$store.state.postCheck === "disabled") {
          this.getDisabledPosts(this.params);
        }


        this.$refs.child.getPostCheckCount();
      } else {
        this.getPostList(this.params);
      }
    }
  }
};
</script>


<style>
#components-layout-basic .header {
  position: fixed;
  z-index: 999;
  width: 100%;
  background: #fff;
  border-bottom: 1px solid #00000021;
}

#components-layout-basic .content {
  margin-top: 64px;
  width: 100%;
  max-width: 1100px;
}

#components-layout-basic .ant-layout-header, .ant-layout-content {
  display: flex;
  align-items: center;
  justify-content: center;
}

#components-layout-basic .ant-layout-header {
  background: #fff;
  height: auto;
  line-height: 2.3;
}

#components-layout-basic .post-check-left-buttons {
  position: relative;
  top: 20px;
}

.index-drawer-wrap .ant-drawer-content-wrapper {
  width: 250px !important;
}

#components-layout-demo-custom-trigger .trigger {
  font-size: 18px;
  line-height: 64px;
  padding: 0 24px;
  cursor: pointer;
  transition: color 0.3s;
}

#components-layout-demo-custom-trigger .trigger:hover {
  color: #1890ff;
}

#components-layout-demo-custom-trigger .logo {
  height: 64px;
  background: rgba(255, 255, 255, 0.2);
  margin: 0;
}
</style>