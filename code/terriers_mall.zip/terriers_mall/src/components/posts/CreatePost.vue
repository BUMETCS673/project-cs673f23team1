<template>
  <div id="create-post">
    <div class="left">
      <a-input class="write-item" v-model="postTitle" :placeholder="$t('common.enterPostTitle')" size="large"/>
      <a-popover v-model="visible" :title="$t('common.releasePost')" trigger="click" placement="bottomRight">
        <div slot="content" style="width: 500px;">
          <PostBasicInfo
              :postUser="postUser"
              :postLabel="postLabel"
              :postTitleMap="postTitleMap"
              :postTitle="postTitle"
              :htmlCode="htmlCode"
              :markdownCode="markdownCode"/>
        </div>
        <a-button class="write-item" type="primary" style="height: 30px;"
                  v-text="$route.params.id ? $t('common.update') : $t('common.release')"></a-button>
      </a-popover>
      <a-icon class="write-item" type="swap"/>
      <a-tooltip placement="bottom">
        <template slot="title">
          {{ $t("common.homePage") }}
        </template>
        <div style="cursor: pointer;" @click="routerUserCenter($store.state.userId)">
          <a-avatar :size="46" slot="avatar" class="write-item"
                    :src="$store.state.picture ? $store.state.picture : require('@/assets/img/default_avatar.png')"/>
        </div>
      </a-tooltip>
    </div>
    <div class="right">
      <mavon-editor ref=md @imgAdd="imgAdd" @change="markdownChange" v-model="markdownCode"
                    :toolbars="toolbars"
                    toolbarsBackground="#f4f4f4"
                    codeStyle="obsidian"
                    :tabSize=4
                    :xssOptions=false
                    boxShadowStyle=""
                    :placeholder="$t('common.startEditing')"></mavon-editor>
    </div>
    
    <Login />

    <Register />
  </div>
</template>

<script>
import postService from "@/service/postService";
import PostBasicInfo from "@/components/posts/PostBasicInfo";
import Login from "@/components/login/Login";
import Register from "@/components/login/Register";

export default {
  components: {PostBasicInfo, Login, Register},

  data() {
    return {
      // post creater
      postUser: 0,
      // post label
      postLabel: [],
      // post title pic
      postTitleMap: '',
      // post title
      postTitle: '',
      // post content
      markdownCode: '',
      htmlCode: '',
      visible: false,
      toolbars: {

        bold: true,

        italic: true,

        header: true,

        underline: true,

        strikethrough: true,

        mark: true,

        superscript: true,

        subscript: true,

        quote: true,

        ol: true,

        ul: true,

        link: true,

        imagelink: true,

        table: true,

        fullscreen: true,

        readmodel: true,

        help: true,

        // last step
        undo: true,
        // next step
        redo: true,
        // clear
        trash: true,

        save: false,
  
        navigation: true,

        // align to left
        alignleft: true,
        // aligh to ceter
        aligncenter: true,
        // align to right
        alignright: true,

        subfield: false,

        preview: true,
      }
    };
  },

  methods: {
    // bind @imgAdd event
    imgAdd(pos, $file) {
      // check size of img(should be less than 5M)
      if ($file.size > 5 * 1024 * 1024) {
        this.$message.warning(this.$t("common.avatarSizeTip"));
        this.$refs.md.$img2Url(pos, null);
        return;
      }
      // First step: upload picture to server
      const formData = new FormData();
      formData.append('picture', $file);
      postService.uploadPicture(formData)
          .then((res) => {
 
            // Second step: change text by url received
            this.$refs.md.$img2Url(pos, res.data);
          })
          .catch(err => {
            this.$message.error(err.desc);
          });
    },

    // get detailed information of post
    getPostById() {
      postService.getPostById({id: this.$route.params.id})
          .then(res => {
            this.postUser = res.data.createUser;
            if (this.$store.state.userId !== this.postUser) {
              this.$message.warning("You don't have access to modify other's post");
              return;
            }
            // title
            this.postTitle = res.data.title;
            // content
            this.markdownCode = res.data.markdown;
            // label
            res.data.labelDTOS.forEach((item) => {
              this.postLabel.push(item.id);
            })
            // title pic
            this.postTitleMap = res.data.titleMap;
          })
          .catch(err => {
            // no such post exist
            if (err.code === 4) {
              this.$router.push({
                name: '404',
                params: { pathMatch: this.$route.path.substring(1).split('/') },
              })
            } else {
              this.$message.error(err.desc);
            }
          });
    },

    markdownChange() {
      this.htmlCode = this.$refs.md.d_render;
    },

    routerUserCenter(userId) {
      if (this.$store.state.isLogin) {
        let routeData = this.$router.resolve("/user/" + userId);
        window.open(routeData.href, '_blank');
      } else {
        this.$store.state.loginVisible = true;
      }
    }
  },

  mounted() {
    if (this.$route.params.id) {
      this.getPostById();
    }
  }
}
</script>

<style>
#create-post {
  height: 100%;
}

#create-post .left {
  height: 8%;
  background: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
}

#create-post .right {
  height: 92%;
}

#create-post .write-item {
  height: auto;
  margin: 0 15px;
}

#create-post .ant-input {
  height: 50px;
  border: none;
  font-size: 26px;
}

#create-post .v-note-wrapper.markdown-body.shadow {
  height: 100%
}

#create-post .markdown-body .highlight pre, .markdown-body pre {
  padding: 0!important;
}
#create-post .hljs {
  padding: 10px;
}

/* markdown */
#create-post .v-note-wrapper {
  z-index: 900;
}

/* markdown */
#create-post .v-note-wrapper.markdown-body.shadow {
  z-index: 0!important;
}
</style>