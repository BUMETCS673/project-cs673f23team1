import axios from "axios";

export default {

  getCarouselList(params) {
    return new Promise((resolve, reject) => {
      axios.get("/api/bbs/carousel/getList", {params})
          .then((res) => resolve(res))
          .catch((err) => reject(err));
    });
  },

};
