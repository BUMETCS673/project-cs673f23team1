import axios from "axios";

export default {

    getCurrentUserAccess() {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/user/getCurrentUserRights")
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    updateLikeCommentState(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/user/updateLikeCommentState", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    updateLikeState(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/user/updateLikeState", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    getHotSellersList(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/user/getHotSellersList", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    getFollowUsers(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/user/getFollowUsers", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    getUserInfo(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/user/getUserInfo", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    getFollowCount(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/user/getFollowCount", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    updateFollowState(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/user/updateFollowState", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    uploadUserPicture(data) {
        return new Promise((resolve, reject) => {
            axios.post("/api/bbs/user/uploadUserPicture", data)
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    updateUserBasicInfo(data) {
        return new Promise((resolve, reject) => {
            axios.post("/api/bbs/user/updateUserBasicInfo", data)
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    sendSmsVerifyCode(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/user/sendSmsVerifyCode", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },
    
    sendEmailVerifyCode(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/user/sendEmailVerifyCode", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    bindPhone(data) {
        return new Promise((resolve, reject) => {
            axios.post("/api/bbs/user/bindPhone", data)
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },
    
    untiePhone(data) {
        return new Promise((resolve, reject) => {
            axios.post("/api/bbs/user/untiePhone", data)
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    bindEmail(data) {
        return new Promise((resolve, reject) => {
            axios.post("/api/bbs/user/bindEmail", data)
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    untieEmail(data) {
        return new Promise((resolve, reject) => {
            axios.post("/api/bbs/user/untieEmail", data)
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    updatePassword(data) {
        return new Promise((resolve, reject) => {
            axios.post("/api/bbs/user/updatePassword", data)
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    isValidEmail(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/user/isValidEmail", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    isValidPhone(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/user/isValidPhone", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    isValidUser(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/user/isValidUser", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    isPhoneExist(data) {
        return new Promise((resolve, reject) => {
            axios.post("/api/bbs/user/isPhoneExist/" + data)
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    isEmailExist(data) {
        return new Promise((resolve, reject) => {
            axios.post("/api/bbs/user/isEmailExist/" + data)
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    phoneResetPassword(data) {
        return new Promise((resolve, reject) => {
            axios.post("/api/bbs/user/phoneResetPassword", data)
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    emailResetPassword(data) {
        return new Promise((resolve, reject) => {
            axios.post("/api/bbs/user/emailResetPassword", data)
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },

    getUserOperateCount(params) {
        return new Promise((resolve, reject) => {
            axios.get("/api/bbs/user/getUserOperateCount", {params})
                .then((res) => resolve(res))
                .catch((err) => reject(err));
        });
    },
};
